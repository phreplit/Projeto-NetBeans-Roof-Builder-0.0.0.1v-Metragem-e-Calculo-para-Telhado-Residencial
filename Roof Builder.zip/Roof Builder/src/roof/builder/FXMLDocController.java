
// Author: PHNO - Tecnólogo | Pós-Graduado
// Data Release: 05/11/2024
// Versão Código: 0.0.0.2v
// Replit: @PHNO, @PHREPLIT
// E-mail: phreplit@gmail.com

// Software: Roof Builder - 0.0.0.2v - Metragem e Calculo para Telhado Residencial, com GUI[interface grafica] e compilacao em ambiente desktop.

package roof.builder;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
//import javafx.scene.control.Button;
//import javafx.scene.control.Label;

/**
 *
 * @author Paulo Henrique
 */
    
public class FXMLDocController implements Initializable {
    
    @FXML
    public TextField textfield;
    public TextField textfield1;
    public TextField textfield2;
    public TextField textfield3;
    public TextField textfield4;
    public TextField textfield5; 
    public TextField textfield6;
    public TextField textfield7;
    public TextField textfield8; 
    public TextField textfield9;
    public TextField textfield10;
    public TextField textfield11; 
    public TextField textfield12;
    public TextField textfield13;
    
    @FXML
    public void reset1(ActionEvent event) {
        textfield.setText("");
        textfield1.setText("");
        textfield2.setText("");
    };
    
    @FXML
    public void reset2(ActionEvent event) {
        textfield3.setText("");
        textfield4.setText("");
        textfield5.setText("");
        textfield6.setText("");
        textfield7.setText("");
    };
    
    @FXML
    public void reset3(ActionEvent event) {
        textfield8.setText("");
        textfield9.setText("");
        textfield10.setText("");
        
    };
    
    @FXML
    public void reset4(ActionEvent event) {
        textfield11.setText("");
        textfield12.setText("");
        textfield13.setText("");

    };
    
     @FXML
    public void calc_1(ActionEvent event) {
        int mult2 = Integer.parseInt(textfield.getText())*Integer.parseInt(textfield1.getText());
	textfield2.setText(String.valueOf(mult2));
    };
    
    @FXML
    public void calc_2(ActionEvent event) {
        int vartwo = 2;			                
	int mult3 = Integer.parseInt(textfield3.getText())+Integer.parseInt(textfield4.getText());
	int mult4 = mult3 / vartwo;			                
	int mult5 = Integer.parseInt(textfield5.getText())+Integer.parseInt(textfield6.getText());
	int mult6 = mult5 / vartwo;
	int result = mult4 * mult6;			                
	textfield7.setText(String.valueOf(result));
    };
    
    @FXML
    public void calc_3(ActionEvent event) {
        int mult8 = Integer.parseInt(textfield11.getText())*Integer.parseInt(textfield12.getText());
	textfield13.setText(String.valueOf(mult8));
    };
    
    @FXML
    public void sum(ActionEvent event) {
        int soma = Integer.parseInt(textfield8.getText())+Integer.parseInt(textfield9.getText());
	textfield10.setText(String.valueOf(soma));
    }
    
    @FXML
    public void sub(ActionEvent event) {
         int sub = Integer.parseInt(textfield8.getText())-Integer.parseInt(textfield9.getText());
	textfield10.setText(String.valueOf(sub));
    }
    
    @FXML
    public void div(ActionEvent event) {
         int div = Integer.parseInt(textfield8.getText())/Integer.parseInt(textfield9.getText());
	textfield10.setText(String.valueOf(div));
    }
    
    @FXML
    public void mult(ActionEvent event) {
         int mult = Integer.parseInt(textfield8.getText())*Integer.parseInt(textfield9.getText());
	textfield10.setText(String.valueOf(mult));
    }
    
    @FXML
    public void info(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION); // mudar para Alert.AlertType.CONFIRMATION, duas opcoes OK e CANCEL
        
        alert.setTitle("Info");
        alert.setContentText("\nPara calcular o metro quadrado do telhado com 4 lados iguais [metragem igual] fazemos o calculo Comprimento x Largura."
+"\nPara calcular o metro quadrado com 4 lados diferentes [metragem diferente] somamos os dois lados paralelos, "
+"\nsomamos o comprimento com comprimento e dividimos por 2 tirando assim a media, "
+"\nfazemos o mesmo com a largura, somamos a largura com largura e dividimos por 2 tirando a media, "
+"\ne com os resultados da media dos lados paralelos (largura e comprimento) "
+"\nmultiplicamos os dois lados parelos Comprimento x Largura e assim obtemos os metros quadrados de um telhado com 4 lados diferentes."
+"\nPara calcular a Quantidade de Telhas por Metro Quadrado: "
+"\nTendo como base uma telha americana com dimensoes (43cx26l) em centimetros em vista de eixo horizontal, "
+"\ne sabendo que calcular um metro quadrado de um telhado sera C x L entao 1 MQ = 12 telhas, "
+"\nassim um metro quadrado tem 12 telhas entao essa sera a medida padrao. 12 x tantos metros quadrados = a quantidade de telhas por metro quadrado."
+"\nPara calcular a Telha Colonial: 1 M² = 16 telhas."
+"\nPara calcular a Telha Italiana: 1 M² = 14 telhas."
+"\nPara calcular a Telha Portuguesa: 1 M² = 17 telhas."
+"\nPara calcular a Telha Romana: "
+"\nTendo como base uma telha romana com dimensoes (40cx21l) em centimetros em vista de eixo horizontal, "
+"\ne sabendo que calcular um metro quadrado de um telhado sera C x L entao 1 MQ = 16 telhas,"
+"\n assim um metro quadrado tem 16 telhas entao essa sera a medida padrao. 16 x tantos metros quadrados = a quantidade de telhas por metro quadrado."
+"\nInformações Importantes: "
+"\nObs: Este software foi desenvolvido com variaveis inteiras, então nao permite a inserção de numero e virgula (ex: 2,90 metros mude para 3 metros)."
+"\nObs: O calculo do metro quadrado de telhado residencial neste software é feito sem o calculo da inclinação. "
+"\nSe o calculo do metro quadrado for feito com a inclinação, com o aumentar do grau de inclinação do telhado, "
+"\nira ocorrer um aumento na quantidade de telhas necessarias para telhar e construir um telhado residencial."
+"\nObs: a instalação, construção e dimensionamento de um telhado residencial requer um profissional qualificado e formado, como um engenheiro civil. "
+"\nPadrão de telhas por Metro Quadrado e Quantidade de Telhas: "
+"\n A quantidade de telhas pode variar para mais ou para menos, a depender das dimensões da telha escolhida, "
+"\nentão veja que no caso da instalação das telhas coloniais, sua arrumação (encaixe) das telhas vai ser feita com duas camadas de telhas, "
+"\no que pode acarretar na variação (para mais ou para menos) da quantidade de telhas necessarias para telhar um metro quadrado. "
+"\n Havendo assim uma possivel diferença no padrão e na quantidade de telhas do metro quadrado para a telha colonial como descrito acima."
+"\nModelo de telhas por Metro Quadrado e Quantidade de Telhas: "
+"\n Caso queira calcular um novo modelo de telha que não esta na tabela de conversão, sera necessario saber as dimensões do novo modelo de telha e saber quantas telhas serão necessarias para telhar um metro quadrado, então sera (N) telhas por 1M².");
        alert.showAndWait();
        
        if(alert.getResult() == ButtonType.OK){
           //
        } // if (alert.getResult() == ButtonType.CANCEL) { 
         // System.exit(0); // ao clicar em cancel, sai da msg de alerta e fecha a aplicação desktop
        //}

    }
    
    @FXML
    public void about(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION); // mudar para Alert.AlertType.CONFIRMATION, duas opcoes OK e CANCEL
        
        alert.setTitle("About");
        alert.setContentText("\nSoftware: Roof Builder - Metragem e Calculo para Telhado Residencial\n"+"\nAuthor: PHNO"+"\nData Release: 08/11/2024"+"\nVersao Codigo: 0.0.0.2v"+"\nReplit: @PHNO, @PHREPLIT"+"\nE-mail: phreplit@gmail.com");
        alert.showAndWait();
        
        if(alert.getResult() == ButtonType.OK){
           //
        } // if (alert.getResult() == ButtonType.CANCEL) { 
         // System.exit(0); // ao clicar em cancel, sai da msg de alerta e fecha a aplicação desktop
        //}

    }
    
    @FXML
    public void cleardata(ActionEvent event) {
        textfield.setText("");
        textfield1.setText("");
        textfield2.setText("");
        textfield3.setText("");
        textfield4.setText("");
        textfield5.setText(""); 
        textfield6.setText("");
        textfield7.setText("");
        textfield8.setText(""); 
        textfield9.setText("");
        textfield10.setText("");
        textfield11.setText(""); 
        textfield12.setText("");
        textfield13.setText("");

    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
